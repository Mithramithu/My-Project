export class NewPassword{
    newPassword :  string;
    contact : string;
    constructor(newPassword, contact){
        this.newPassword = newPassword;
        this.contact = contact;
    }
}