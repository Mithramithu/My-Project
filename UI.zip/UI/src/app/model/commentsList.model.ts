export class CommentsList{
    list : Array<Comment>;
}